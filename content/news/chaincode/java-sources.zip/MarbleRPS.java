class MarbleRPS extends org.hyperledger.fabric.shim.ChaincodeBase {

    public static final int ROCK = 0;
    public static final int PAPER = 1;
    public static final int SCISSORS = 2;


    /*@
      @ normal_behaviour
      @ ensures \dl_seqLen(stub.transactionLog) == \dl_seqLen(\old(stub.transactionLog)) + 1;
      @ ensures \dl_getPlayerId(\dl_deserializeLedgerData( (\seq) \dl_getValue(\dl_lastEntry(stub.transactionLog, pid)))) == pid;
      @*/
    static Response createNewPlayer(org.hyperledger.fabric.shim.ChaincodeStub stub, int pid, String name) {
        Player p = new Player(pid, name);
        stub.putState(pid, p.serialize());
        return newSuccessResponse("Yay");
    }

    static Response createNewMarble(org.hyperledger.fabric.shim.ChaincodeStub stub,
            int id, int ownerId, int size, int color) {
        Marble m = new Marble(id, ownerId, size, color);
        stub.putState(id, m.serialize());
        return newSuccessResponse("Yay");
    }

    static Response createNewGame(org.hyperledger.fabric.shim.ChaincodeStub stub, int marbleId, int gameId) {
        if (Game.deserialize(stub.getState(gameId)) != null) return newErrorResponse("This ID is not free.");
        int p1Id = org.hyperledger.fabric.shim.CID.getCid();
        Player p = Player.deserialize(stub.getState(p1Id));
        Marble m = Marble.deserialize(stub.getState(marbleId));
        if (m.ownerId != p1Id) return newErrorResponse("Play with your own marbles!");
        Game g = new Game(p, m);
        stub.putState(gameId, g.serialize());
        return newSuccessResponse("Game created!");
    }

    static Response joinGame(org.hyperledger.fabric.shim.ChaincodeStub stub, int gameId, int mId) {
        Marble m = Marble.deserialize(stub.getState(mId));
        int p2Id = org.hyperledger.fabric.shim.CID.getCid();
        Player p = Player.deserialize(stub.getState(p2Id));
        if (m.ownerId != p2Id) return newErrorResponse("Play with your own marbles!");
        Game g = Game.deserialize(stub.getState(gameId));
        g.p2 = p;
        g.m2 = m;
        stub.putState(gameId, g.serialize());
        return newSuccessResponse("Yay");
    }

    /*@
      @ requires
      @     \dl_readGame(stub.transactionLog, gameId) == null
      @  || (\dl_getGameSign1(\dl_readGame(stub.transactionLog, gameId)) != -1 && \dl_getGameSign2(\dl_readGame(stub.transactionLog, gameId)) != -1)
      @  || (\dl_getGameP2(\dl_readGame(stub.transactionLog, gameId)) == null)
      @  || (sign < 0 || sign > 2);
      @ ensures stub.transactionLog == \old(stub.transactionLog);
      @ assignable \nothing;
      @     also
      @ requires
      @     !(\dl_readGame(stub.transactionLog, gameId) == null
      @  || (\dl_getGameSign1(\dl_readGame(stub.transactionLog, gameId)) != -1 && \dl_getGameSign2(\dl_readGame(stub.transactionLog, gameId)) != -1)
      @  || (\dl_getGameP2(\dl_readGame(stub.transactionLog, gameId)) == null)
      @  || (sign < 0 || sign > 2));
      @ ensures (evaluate(\dl_getGameSign1(\dl_readGame(stub.transactionLog, gameId)), \dl_getGameSign2(\dl_readGame(stub.transactionLog, gameId))) == 1)
      @     ==> \dl_getMarbleOwnerId(\dl_getGameM2(\dl_readGame(stub.transactionLog, gameId))) == \dl_getPlayerId(\dl_getGameP1(\dl_readGame(stub.transactionLog, gameId)));
      @*/
    static Response play(org.hyperledger.fabric.shim.ChaincodeStub stub, int gameId, int sign) {
        int pid = org.hyperledger.fabric.shim.CID.getCid();
        Player p = (Player) org.hyperledger.fabric.shim.LedgerData.deserialize(stub.getState(pid));
        Game g = (Game) org.hyperledger.fabric.shim.LedgerData.deserialize(stub.getState(gameId));
        if (g == null || g.p2 == null || (g.sign1 != -1 && g.sign2 != -1) || (sign < 0 || sign > 2)) {
            return newErrorResponse("No game, or already finished, or impossible sign.");
        }
        if (pid == g.p1.id) {
            if (g.sign1 != -1) return newErrorResponse("Already played.");
            g.sign1 = sign;
        } else if (pid == g.p2.id) {
            if (g.sign2 != -1) return newErrorResponse("Already played.");
            g.sign2 = sign;
        } else return newErrorResponse("Wrong player id.");

        if (g.sign1 != -1 && g.sign2 != -1) {
            int winner = evaluate(g.sign1, g.sign2);
            Marble m;
            switch (winner) {
                case 0 : return newSuccessResponse("Game drawn.");
                case 1 : m = org.hyperledger.fabric.shim.LedgerData.deserialize(stub.getState(g.m2.id));
                         m.ownerId = g.p1.id;
                         stub.putState(g.m2.id, m.serialize());
                         return newSuccessResponse("Player 1 won.");
                case 2 : m = org.hyperledger.fabric.shim.LedgerData.deserialize(stub.getState(g.m1.id));
                         m.ownerId = g.p2.id;
                         stub.putState(g.m1.id, m.serialize());
                         return newSuccessResponse("Player 1 won.");
            }
        }
        return newSuccessResponse("Nothing to see here, please move on");
    }

    /*@
      @ requires 0 <= s1 && s1 <= 2;
      @ requires 0 <= s2 && s2 <= 2;
      @ ensures s1 == s2 ==> \result == 0;
      @ ensures (s1 == ROCK && s2 == SCISSORS
      @       || s1 == SCISSORS && s2 == PAPER
      @       || s1 == PAPER && s2 == ROCK)
      @     ==> \result == 1;
      @ ensures (s2 == ROCK && s1 == SCISSORS
      @       || s2 == SCISSORS && s1 == PAPER
      @       || s2 == PAPER && s1 == ROCK)
      @     ==> \result == 2;
      @*/
    private static int evaluate(int s1, int s2){
        return (3 + s1 - s2) % 3;
    }

    public Response invoke(org.hyperledger.fabric.shim.ChaincodeStub stub) {
        return null;
    }

    public Response init(org.hyperledger.fabric.shim.ChaincodeStub stub) {
        return null;
    }
}

//Asset definitions
class Marble extends org.hyperledger.fabric.shim.LedgerData {
    public int id, ownerId, size, color;

    public Marble (int id, int ownerId, int size, int color) {
        this.id = id;
        this.ownerId = ownerId;
        this.size = size;
        this.color = color;
    }

    //public byte[] serialize() {
    //    return null;
    //}

    ///*@ public normal_behaviour
    //  ensures \dl_object2Marble(\result) == \dl_deserializeMarble(\dl_array2seq(bytes));
    //  ensures \fresh(\result);
    //  assignable \nothing;                
    //  @*/
    //public static Marble deserialize(byte[] bytes) {
    //    return null;
    //}
}

class Player extends org.hyperledger.fabric.shim.LedgerData {
    public int id;
    public String name;

    public Player (int id, String name) {
        this.id = id;
        this.name = name;
    }

    //public byte[] serialize() {
    //    return null;
    //}

    ///*@ public normal_behaviour
    //  ensures \dl_object2Player(\result) == \dl_deserializePlayer(\dl_array2seq(bytes));
    //  ensures \fresh(\result);
    //  assignable \nothing;                
    //  @*/
    //public static Player deserialize(byte[] bytes) {
    //    return null;
    //}
}

class Game extends org.hyperledger.fabric.shim.LedgerData {
    int sign1, sign2;
    Player p1, p2;
    Marble m1, m2;

    public Game(Player p1, Marble m1) {
        this.sign1 = -1;
        this.sign2 = -1;
        this.p1 = p1;
        this.m1 = m1;
    }

    //public byte[] serialize() {
    //    return null;
    //}

    ///*@ public normal_behaviour
    //  ensures \dl_object2Game(\result) == \dl_deserializeGame(\dl_array2seq(bytes));
    //  ensures \fresh(\result);
    //  assignable \nothing;                
    //  @*/
    //public static Game deserialize(byte[] bytes) {
    //    return null;
    //}
}
